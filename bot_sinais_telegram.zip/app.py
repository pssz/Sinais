
from flask import Flask
from telegram_service import send_alert

app = Flask(__name__)

@app.route('/')
def index():
    return "Bot de sinais ativo com sucesso!"

@app.route('/alerta')
def alerta():
    send_alert("🚨 Sinal gerado automaticamente pelo bot!")
    return "Alerta enviado!"
