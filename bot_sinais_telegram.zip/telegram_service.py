
import requests

# Token e chat_id fixos (você pode configurar isso no Railway como variáveis de ambiente)
TOKEN = '7941483316:AAHqwTYbf6Ur2OxVJjf1l61R1eu8K7Gjtis'
CHAT_ID = '1369730063'

def send_alert(mensagem):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    data = {"chat_id": CHAT_ID, "text": mensagem}
    requests.post(url, data=data)
